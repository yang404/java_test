package cn.itcast.day04.demo01;

public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello, World!111");
    }

}
